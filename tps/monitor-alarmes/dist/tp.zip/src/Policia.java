
public class Policia implements ServicoExterno {
	@Override
	public void chamar() {
		System.out.println("Chamar policia");
	}

}
