
public class Sistema {
	Central central = new Central();
	
	public static void main(String[] args) {
		System.out.println("Sistema de Monitoramento de Alarmes");
	}

}
