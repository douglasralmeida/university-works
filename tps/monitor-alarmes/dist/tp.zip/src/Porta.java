
public class Porta {
	void fechar() {
		System.out.println("Fechar porta");
	}
}
