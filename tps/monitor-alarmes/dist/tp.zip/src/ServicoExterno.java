
public interface ServicoExterno {
	public void chamar();
}
