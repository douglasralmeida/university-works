
public class Bombeiros implements ServicoExterno {
	@Override
	public void chamar() {
		System.out.println("Chamar bombeiros");
	}
}
