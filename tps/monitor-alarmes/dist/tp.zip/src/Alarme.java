
public interface Alarme {
	void chamarServicoExterno();
}
