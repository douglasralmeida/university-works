
public class EquipamentoCombate {
	public void acionar() {
		System.out.println("Acionar equipamento combate.");
	}
}
