/*
**	FUNCOES PARA MANIPUALAÇÃO DE STRINGS
**	DOUGLAS RODRIGUES DE ALMEIDA
**
**	Funções para manipulação de cadeia de caracteres
**	
**/

#ifndef STRUTILS_H
#define STRUTILS_H

#include "boolutils.h"
#include "core.h"

bool StrComparar(void* String1, void* String2);
#endif
