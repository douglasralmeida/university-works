/*
**	TIPO BOOLEANO
**	DOUGLAS RODRIGUES DE ALMEIDA
**
**	Tipo booleano para o padrao C89
**	
**/

#ifndef BOOLUTILS_H
#define BOOLUTILS_H

/* Emulacao do tipo booleano */
typedef enum {
	false, true
	} bool;

#endif
