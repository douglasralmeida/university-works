/*
**	RELOGIO
**	DOUGLAS RODRIGUES DE ALMEIDA
**
**	Emula a hora do sistema
**	
**/

#include "time.h"
#include "hora.h"

time_t horaatual = (time_t)0;
