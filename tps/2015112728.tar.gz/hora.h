/*
**	RELOGIO
**	DOUGLAS RODRIGUES DE ALMEIDA
**
**	Emula a hora do sistema
**	
**/

#ifndef HORA_C
#define HORA_C

/* Hora Atual do Sistema */
/* Variavel global acessada por toda a aplicacao */
extern time_t horaatual; 

#endif

