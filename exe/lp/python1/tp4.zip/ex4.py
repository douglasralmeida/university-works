## Escreva um programa que receba um inteiro n e um nome f de arquivo como
## argumentos e imprima arquivos com no maximo n linhas contendo cada um n
## linhas do arquivo f: 
## o -esimo arquivo contem as linhas de numero (i-1) * n+1 a i * n, para i 
## comecando de 1 ate que as linhas do arquivo f terminem.

import itertools

def yieldfunc(texto):
    for lin in texto:
        yield lin

def imprimir(arq):
    for lin in arq:
        print(lin)
    print('\n')
    
def processar(n, tam, texto):
    i = 1
    j = 1
    while (i < tam):
        li = (i-1) * n + 1
        lf = i*n
        while (j < li):
            yieldfunc(texto)
            j += 1
        j = li+1
        arq = yieldfunc(texto)
        while (j <= lf):
            itertools.chain(arq, yieldfunc(texto))
            j += 1
        imprimir(arq)
        i += 1
        
def tamtexto(texto):
    return sum(1 for _ in texto)

def main(n, arq):
    texto = open(arq, 'rt')
    totallinhas = tamtexto(texto)
    texto.seek(0)
    processar(n, totallinhas, texto)

main(5, 'z')


#i 	li 		   lf
#1	0+1		   n                0 1
#2	1*n+1		2*n              3 4
#3	2*n+1		3*n              7 9
#...........................
#n	(n-1)*n+1	n*n